﻿Public Class Form1
    Dim FirstNumber, SeconNumber, Answer As Single
    Dim ArithmeticProcess As String
    Dim button As Integer
    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOn.Click
        ' Dim on as Integer
        'On = on

    End Sub

    Private Sub Btn12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMinus.Click

    End Sub

    Private Sub Btn1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn1.Click
        Dim one As Integer
        one = 1
        Lbl1.Text = Lbl1.Text + "1"
        TextBox1.Text = TextBox1.Text + "1"

    End Sub

    Private Sub Btn2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn2.Click
        Dim two As Integer
        two = 2
        Lbl1.Text = Lbl1.Text + "2"


    End Sub

    Private Sub Btn3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn3.Click
        Dim three As Integer
        three = 3
        Lbl1.Text = Lbl1.Text + "3"
    End Sub

    Private Sub Btn4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn4.Click
        Dim four As Integer
        four = 4
        Lbl1.Text = Lbl1.Text + "4"



    End Sub

    Private Sub btn5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn5.Click
        Dim five As Integer
        five = 5
        Lbl1.Text = Lbl1.Text + "5"
    End Sub

    Private Sub btn6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn6.Click
        Dim six As Integer
        six = 6
        Lbl1.Text = Lbl1.Text + "6"


    End Sub

    Private Sub btn7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn7.Click
        Dim seven As Integer
        seven = 7
        Lbl1.Text = Lbl1.Text + "7"
    End Sub

    Private Sub btn8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn8.Click
        Dim eight As Integer
        eight = 8
        Lbl1.Text = Lbl1.Text + "8"

    End Sub

    Private Sub btn9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn9.Click
        Dim nine As Integer
        nine = 9
        Lbl1.Text = Lbl1.Text + "9"


    End Sub

    Private Sub btn0_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn0.Click
        Dim zero As Integer
        zero = 0
        Lbl1.Text = Lbl1.Text + "0"


    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        ' Dim delete As Integer
        'delete = delete

    End Sub

    Private Sub btnDivision_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDivision.Click

    End Sub

    Private Sub btnPlus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPlus.Click
        Lbl1.Text = Lbl1.Text + "+"
       
    End Sub

    Private Sub btnEquals_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEquals.Click
        SeconNumber = Val(Lbl1.Text)
        If ArithmeticProcess = "+" Then
            Answer = FirstNumber + SeconNumber
            Lbl1.Text = Answer
            MessageBox.Show("problem")
        End If

    End Sub

    Private Sub btnDot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDot.Click

    End Sub
End Class
