﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Ch1 = New System.Windows.Forms.CheckBox()
        Me.Ch2 = New System.Windows.Forms.CheckBox()
        Me.Ch3 = New System.Windows.Forms.CheckBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Btn1 = New System.Windows.Forms.Button()
        Me.Btn2 = New System.Windows.Forms.Button()
        Me.Lbl1 = New System.Windows.Forms.Label()
        Me.Lbl2 = New System.Windows.Forms.Label()
        Me.Lbl3 = New System.Windows.Forms.Label()
        Me.Btn3 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Ch1
        '
        Me.Ch1.AutoSize = True
        Me.Ch1.Location = New System.Drawing.Point(12, 32)
        Me.Ch1.Name = "Ch1"
        Me.Ch1.Size = New System.Drawing.Size(89, 17)
        Me.Ch1.TabIndex = 0
        Me.Ch1.Text = "wash and set"
        Me.Ch1.UseVisualStyleBackColor = True
        '
        'Ch2
        '
        Me.Ch2.AutoSize = True
        Me.Ch2.Location = New System.Drawing.Point(12, 71)
        Me.Ch2.Name = "Ch2"
        Me.Ch2.Size = New System.Drawing.Size(67, 17)
        Me.Ch2.TabIndex = 1
        Me.Ch2.Text = "Retouch"
        Me.Ch2.UseVisualStyleBackColor = True
        '
        'Ch3
        '
        Me.Ch3.AutoSize = True
        Me.Ch3.Location = New System.Drawing.Point(12, 107)
        Me.Ch3.Name = "Ch3"
        Me.Ch3.Size = New System.Drawing.Size(53, 17)
        Me.Ch3.TabIndex = 2
        Me.Ch3.Text = "Relax"
        Me.Ch3.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(323, 12)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(197, 180)
        Me.TextBox1.TabIndex = 3
        '
        'Btn1
        '
        Me.Btn1.Location = New System.Drawing.Point(12, 169)
        Me.Btn1.Name = "Btn1"
        Me.Btn1.Size = New System.Drawing.Size(75, 41)
        Me.Btn1.TabIndex = 4
        Me.Btn1.Text = "Calculator"
        Me.Btn1.UseVisualStyleBackColor = True
        '
        'Btn2
        '
        Me.Btn2.ForeColor = System.Drawing.Color.DarkSlateBlue
        Me.Btn2.Location = New System.Drawing.Point(230, 169)
        Me.Btn2.Name = "Btn2"
        Me.Btn2.Size = New System.Drawing.Size(75, 41)
        Me.Btn2.TabIndex = 5
        Me.Btn2.Text = "Print"
        Me.Btn2.UseVisualStyleBackColor = True
        '
        'Lbl1
        '
        Me.Lbl1.AutoSize = True
        Me.Lbl1.Location = New System.Drawing.Point(127, 36)
        Me.Lbl1.Name = "Lbl1"
        Me.Lbl1.Size = New System.Drawing.Size(31, 13)
        Me.Lbl1.TabIndex = 6
        Me.Lbl1.Text = "2000"
        '
        'Lbl2
        '
        Me.Lbl2.AutoSize = True
        Me.Lbl2.Location = New System.Drawing.Point(127, 75)
        Me.Lbl2.Name = "Lbl2"
        Me.Lbl2.Size = New System.Drawing.Size(31, 13)
        Me.Lbl2.TabIndex = 7
        Me.Lbl2.Text = "3000"
        '
        'Lbl3
        '
        Me.Lbl3.AutoSize = True
        Me.Lbl3.Location = New System.Drawing.Point(127, 111)
        Me.Lbl3.Name = "Lbl3"
        Me.Lbl3.Size = New System.Drawing.Size(25, 13)
        Me.Lbl3.TabIndex = 8
        Me.Lbl3.Text = "400"
        '
        'Btn3
        '
        Me.Btn3.Location = New System.Drawing.Point(114, 174)
        Me.Btn3.Name = "Btn3"
        Me.Btn3.Size = New System.Drawing.Size(79, 36)
        Me.Btn3.TabIndex = 9
        Me.Btn3.Text = "Total"
        Me.Btn3.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gainsboro
        Me.ClientSize = New System.Drawing.Size(525, 219)
        Me.Controls.Add(Me.Btn3)
        Me.Controls.Add(Me.Lbl3)
        Me.Controls.Add(Me.Lbl2)
        Me.Controls.Add(Me.Lbl1)
        Me.Controls.Add(Me.Btn2)
        Me.Controls.Add(Me.Btn1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Ch3)
        Me.Controls.Add(Me.Ch2)
        Me.Controls.Add(Me.Ch1)
        Me.ForeColor = System.Drawing.Color.DarkBlue
        Me.Name = "Form1"
        Me.Text = "JOY SALOON"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Ch1 As System.Windows.Forms.CheckBox
    Friend WithEvents Ch2 As System.Windows.Forms.CheckBox
    Friend WithEvents Ch3 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Btn1 As System.Windows.Forms.Button
    Friend WithEvents Btn2 As System.Windows.Forms.Button
    Friend WithEvents Lbl1 As System.Windows.Forms.Label
    Friend WithEvents Lbl2 As System.Windows.Forms.Label
    Friend WithEvents Lbl3 As System.Windows.Forms.Label
    Friend WithEvents Btn3 As System.Windows.Forms.Button

End Class
